### Installation:
```bash
git clone https://github.com/yourusername/crypto-forecasting.git
cd crypto-forecasting
pip install -r requirements.txt
```
### Training:
```bash
python train.py --config configs/train_config.yaml
```
